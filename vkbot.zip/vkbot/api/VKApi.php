<?php

namespace api;

class VKApi
{
    function __construct()
    {
        echo "создался новый класс VkApi";
    }
}
